﻿using System;

namespace DotNet.Highcharts.Samples.Models
{
    public class DataClass
    {
        public DateTime ExecutionDate { get; set; }
        public double ExecutionValue { get; set; }
    }
}